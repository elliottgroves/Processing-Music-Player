import processing.core.*; 
import processing.data.*; 
import processing.event.*; 
import processing.opengl.*; 

import ddf.minim.*; 
import ddf.minim.analysis.*; 
import java.awt.Toolkit; 
import java.awt.datatransfer.*; 

import java.util.HashMap; 
import java.util.ArrayList; 
import java.io.File; 
import java.io.BufferedReader; 
import java.io.PrintWriter; 
import java.io.InputStream; 
import java.io.OutputStream; 
import java.io.IOException; 

public class ProcessingMusicPlayer extends PApplet {






Minim minim;
AudioPlayer song;
FFT fft;
PFont f;

ArrayList<Button> buttons;
ArrayList<String> songs;
int current = 0, dispheight = 50, dispColor = 0, dispPos = 0, dispDist = 0;
float easing = 0.09f;
String songList = "", input = "";

boolean startUp = true, paused = false, scrolling = false, backScrolling = false, typing = false;
int[] colors;
int colorScheme = 1;

public void setup() {
  
  //size(1920,1200);
  noStroke();
  
  colors = new int[3];
  for(int c = 0; c < colors.length; c++) {
    colors[c] = 0; 
  }
  
  buttons = new ArrayList<Button>();
  buttons.add(new Button(0,0,width/3,height - dispheight,"(BASS)",colors));
  buttons.add(new Button(width/3,0,width/3,height - dispheight,"(MID)",colors));
  buttons.add(new Button(2 * width/3,0,width/3,height - dispheight,"(TREBLE)",colors));
  buttons.add(new Button(width-dispheight,height-dispheight,dispheight,dispheight,"+",colors));
  buttons.get(3).depth = 5;
  
  f = createFont("Gulim", 48);
  textFont(f, 48);
  
  songs = new ArrayList<String>();
  songs.add("mazy - afternoon couch slash nightclub floor");
  songs.add("mazy - breathe forest air");
  songs.add("mazy - magic cylinder");
  songs.add("mazy - footsie heartrace");
  
  //this is what you call "lazy formatting"
  for(int i = 0; i < songs.size(); i++) {
    songs.set(i, songs.get(i) + "http://");
    if(i == songs.size() - 1) songList += songs.get(i).substring(0,songs.get(i).indexOf("http://")).toUpperCase() + " >> ";
    else songList += songs.get(i).substring(0,songs.get(i).indexOf("http://")).toUpperCase() + " || "; 
  }
  
  minim = new Minim(this);
  song = minim.loadFile(songs.get(current).substring(0,songs.get(current).indexOf("http://")) + ".mp3", 1024);
  
  fft = new FFT(song.bufferSize(), song.sampleRate());
}

public void draw() {
  background(0);
  fft.forward(song.mix);
  
  //update buttons for clicks and such
  for(int i = 0; i < buttons.size(); i++) {
    buttons.get(i).update(); 
  }
  
  if(startUp) {
    //button text
    colors[1] = 255;
    if(frameCount > 100  && frameCount < 200 && frameCount % 10 == 0 && !buttons.get(2).disp.equals("")) {
       for(int i = 0; i < buttons.size() - 1; i++) {
         if(!buttons.get(i).disp.equals("") && buttons.get(i).disp.charAt(buttons.get(i).disp.length()-1) != ' ')
           buttons.get(i).disp = buttons.get(i).disp.substring(0,buttons.get(i).disp.length()-1);
         buttons.get(i).update();
       }
    } else if(frameCount > 230 && frameCount < 350) {
       buttons.get(0).disp = "EN";
       buttons.get(1).disp = "JO";
       buttons.get(2).disp = "Y.";
    } else if(frameCount > 350) {
       buttons.get(0).disp = "<";
       buttons.get(1).disp = "||";
       buttons.get(2).disp = ">";
       song.play();
       startUp = false;
    }
  } else {
    //display currently playing song
    int offset = PApplet.parseInt(height/150);
    textAlign(LEFT);
    if(!typing) {
      fill(50);
      text(songList.toUpperCase(), offset - dispPos, height - offset);
      fill(255);
      if(!scrolling && !backScrolling) text(songs.get(current).substring(0,songs.get(current).indexOf("http://")).toUpperCase(), offset, height - offset);
    } else {
      fill(255);
      if(textWidth(input) > width-dispheight) {
        text(input, -(textWidth(input)-(width-dispheight)), height - offset); 
      } else {
        text(input, offset, height - offset);
      }
    }
    
    //scroll display
    int ridiculous = PApplet.parseInt(textWidth(songList.substring(0,songList.indexOf(songs.get(current).substring(0,songs.get(current).indexOf("http://")).toUpperCase()))));
    if(scrolling && dispPos < ridiculous) {
      dispDist = ridiculous - dispPos;
      if(dispDist > 6) {
        if(PApplet.parseInt(dispDist * easing) > 1)
          dispPos += PApplet.parseInt(dispDist * easing);
        else
          dispPos += 2;
      } else {
        dispPos = ridiculous;
        scrolling = false;
      }
    } else if(backScrolling && dispPos > PApplet.parseInt(textWidth(songList.substring(0,songList.indexOf(songs.get(current).substring(0,songs.get(current).indexOf("http://")).toUpperCase()))))) {
      ridiculous = PApplet.parseInt(textWidth(songList.substring(0,songList.indexOf(songs.get(current).substring(0,songs.get(current).indexOf("http://")).toUpperCase()))));
      dispDist = dispPos - ridiculous;
      if(dispDist > 6) {
        if(PApplet.parseInt(dispDist * easing) > 1)
          dispPos -= PApplet.parseInt(dispDist * easing);
        else
          dispPos -= 2;
      } else {
        dispPos = ridiculous;
        backScrolling = false;
      }
    }
  
    //(overlay text)
    buttons.get(3).update(); 
     
    //auto-advance through songs
    if(song.isPlaying() == false && paused == false) next();
  
    //pull the b-r-y from freq spectrum
    for(int f = 0; f < colors.length; f++) {
      colors[f] = 0;
    
      for(int s = 0; s < 300 / colors.length; s++) {
         colors[f] += fft.getBand(f*300/colors.length + s)*60;
      }
    
      colors[f] /= fft.specSize() / colors.length;
    
      if(f == 0) colors[f] = PApplet.parseInt(colors[f]/1.8f);
      if(f == 2) colors[f] *= 2.2f;
    
      if(colors[f] > 255) colors[f] = 255;
    }
    
    //custom set color ranges
    switch(colorScheme) {
      case 1:
        buttons.get(0).dark = color(PApplet.parseInt(colors[0]/10), 0, colors[0]);
        buttons.get(1).dark = color(colors[1], 0, 0);
        buttons.get(2).dark = color(colors[2], colors[2], PApplet.parseInt(colors[2]/3));
        break;
      case 2:
        buttons.get(0).dark = color(0, colors[0], 0);
        buttons.get(1).dark = color(map(colors[1], 0, 255, 0, 150));
        buttons.get(2).dark = color(0, 0, colors[2]);
        break;
      case 3:
        buttons.get(0).dark = color(colors[0], 0, 0);
        buttons.get(1).dark = color(0, colors[1], 0);
        buttons.get(2).dark = color(0, 0, colors[2]);
        break;
      case 4:
        buttons.get(0).dark = color(colors[0], colors[0], 0);
        buttons.get(1).dark = color(0, colors[1], 0);
        buttons.get(2).dark = color(0, 0, colors[2]);
        break;
      case 5:
        buttons.get(0).dark = color(colors[0], colors[0], colors[0]);
        buttons.get(1).dark = color(colors[1], colors[1], colors[1]);
        buttons.get(2).dark = color(colors[2], colors[2], colors[2]);
        break;
      case 6:
        buttons.get(0).dark = color(colors[0], colors[1], colors[2]);
        buttons.get(1).dark = color(colors[0], colors[1], colors[2]);
        buttons.get(2).dark = color(colors[0], colors[1], colors[2]);
        break;
      case 7:
        buttons.get(0).dark = color(max(colors[0],colors[1],colors[2]));
        buttons.get(1).dark = color(max(colors[0],colors[1],colors[2]));
        buttons.get(2).dark = color(max(colors[0],colors[1],colors[2]));
        break;
    }
    if(!paused) buttons.get(3).dark = color(0, 100, 0);
    else buttons.get(3).dark = color(0, 0, 0);
    
    for(int u = 0; u < buttons.size(); u++) {
      buttons.get(u).updateColor(); 
    }
    
    //explicitly set button functions
    if(buttons.get(0).pressed) {
      previous();
      buttons.get(0).pressed = false; 
    } else if(buttons.get(1).pressed) { 
      pause();
      buttons.get(1).pressed = false;
    } else if(buttons.get(2).pressed) {
      next();
      buttons.get(2).pressed = false;
    } else if(buttons.get(3).pressed) {
      load();
      buttons.get(3).pressed = false; 
    }
  }
}

public void previous() {
  if(current > 0) current--;
  else {
    current = songs.size() - 1;
    scrolling = true;
    playCurrent();
    return;
  }
  
  playCurrent();
  backScrolling = true;
  if(scrolling) scrolling = false;
}

public void pause() {
  if(song.isPlaying()) {
    paused = true;
    song.pause();
  } else {
    paused = false;
    song.play();
  }
}

public void next() {
  if(current < songs.size() - 1) current++; 
  else {
    current = 0;
    backScrolling = true;
    playCurrent();
    return;
  }
  
  playCurrent();
  
  scrolling = true;
  if(backScrolling) backScrolling = false;
}

public void load() {
  input = "url(with www.):::title + enter(tab=paste)";
  typing = true;
}

public void loadFromUrl() {
  songList = songList.substring(0,songList.length()-3) + " || " + input.substring(input.indexOf(":::") + 3, input.length()).toUpperCase() + " >>";
  if(input.indexOf("http://") == -1)
    songs.add(input.substring(input.indexOf(":::") + 3, input.length()) + "http://" + input.substring(0,input.indexOf(":::")));
  else
    songs.add(input.substring(input.indexOf(":::") + 3, input.length()) + input.substring(0,input.indexOf(":::")));
  input = ""; 
}

public void playCurrent() {
  song.close();
  if(songs.get(current).indexOf("http://") + 7 != songs.get(current).length()) {
    song = minim.loadFile(songs.get(current).substring(songs.get(current).indexOf("http://"), songs.get(current).length()), 1024);
  } else {
    song = minim.loadFile(songs.get(current).substring(0,songs.get(current).indexOf("http://")) + ".mp3", 1024);
  }
  if(!paused) song.play();
}

public void paste() {
  String clpbrd = null;
  try {
    clpbrd = (String)Toolkit.getDefaultToolkit().getSystemClipboard().getContents(null).getTransferData(DataFlavor.stringFlavor);
  } catch (Exception e) {
    
  }
  input += clpbrd;
}

public void mousePressed() {
  int found = -1;
  for(int i = 0; i < buttons.size(); i++) {
    if(buttons.get(i).mouseOver) found = i;
  } 
  
  if(found != -1) buttons.get(found).pressed = true;
}

public void keyPressed() {
  if(input.equals("url(with www.):::title + enter(tab=paste)")) input = "";
  
  if(!typing) {
    int press = -1;
    if(key == ' ' || key == ESC) {
      press = 1;
      key = 0;
    } else if(key == ENTER || key == RETURN) {
      press = 3;
    } else if(key == CODED) {
      if(keyCode == RIGHT) {
        press = 2;
      } else if(keyCode == LEFT) {
        press = 0;
      }
    } else {
      switch(key) {
        case '1':
          colorScheme = 1;
          break;
        case '2':
          colorScheme = 2;
          break;
        case '3':
          colorScheme = 3;
          break;
        case '4':
          colorScheme = 4;
          break;
        case '5':
          colorScheme = 5;
          break;
        case '6':
          colorScheme = 6;
          break;
        case '7':
          colorScheme = 7;
          break;
      }
      
      if(PApplet.parseInt(key) > 0 && PApplet.parseInt(key) < 7) colorScheme = PApplet.parseInt(key);
    }
    if(press > -1 && !buttons.get(press).pressing) buttons.get(press).pressed = true;
  } else {
    if(key == ESC) {
      typing = false;
      key = 0;
    } else if(key == BACKSPACE && !input.equals("")) {
      input = input.substring(0,input.length()-1);
    } else if(key == CODED && keyCode == TAB) {
      paste();
    } else if(key == CODED) {
      
    } else if(key == ENTER || key == RETURN) {
      if(input.equals("")) {
        typing = false;
        return;
      } else if(input.indexOf(":::") == -1) {
        input = "url(with www.):::title + enter(tab=paste)";
        return;
      }
      typing = false;
      loadFromUrl();
    } else {
      input += key;
    }
  }
}

public void mouseReleased() {
  for(int i = 0; i < buttons.size(); i++) {
    buttons.get(i).pressing = false;
  } 
}

public void keyReleased() {
  for(int i = 0; i < buttons.size(); i++) {
    buttons.get(i).pressing = false;
  } 
}

public void stop() {
  song.close();
  minim.stop();
 
  super.stop(); 
}

class Button {
  int x, y, w, h;
  boolean pressed = false, mouseOver = false, pressing = false;
  String disp = "";
  int depth = 20;
  int dark, light;
  int[] colors;
  
  Button(int x1, int y1, int w1, int h1, String txt, int[] cols) {
    x = x1;
    y = y1;
    w = w1;
    h = h1;
    disp = txt;
    colors = cols;
    
    updateColor();
  }
  
  public void update() { 
    if(mouseX > x && mouseX < x + w && mouseY > y && mouseY < y + h) {
      mouseOver = true;
    } else {
      mouseOver = false;
    }
    
    if(pressed) pressing = true; 
    
    if(pressing == false) {
      fill(dark);
      rect(x, y, w, h);
      fill(light);
      rect(x + depth, y + depth, w - depth*2, h - depth*2);
    } else {
      fill(light);
      rect(x, y, w, h);
      fill(dark);
      rect(x + depth, y + depth, w - depth*2, h - depth*2);
    }
    
    updateColor();
    
    fill(color(colors[1], colors[1], colors[1]));
    textAlign(CENTER);
    text(disp, w/2 + x, h/2 + y + 17);
  }
  
  public void updateColor() {
    if(red(dark) < 240 && green(dark) < 240 && blue(dark) < 240) {
      light = color(red(dark) + 15, green(dark) + 15, blue(dark) + 15);
    } else {
      light = dark; 
    }
  }
}
  public void settings() {  fullScreen(); }
  static public void main(String[] passedArgs) {
    String[] appletArgs = new String[] { "--present", "--window-color=#666666", "--stop-color=#cccccc", "ProcessingMusicPlayer" };
    if (passedArgs != null) {
      PApplet.main(concat(appletArgs, passedArgs));
    } else {
      PApplet.main(appletArgs);
    }
  }
}
